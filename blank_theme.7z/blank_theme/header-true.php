<header class="header headerFixed">
    <div class="container">
        <div class="row">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="Logo" class="web_logo img-responsive"/>
            </a>
            <div role="navigation">
                <?php
                    wp_nav_menu( array(
                        'menu'              => 'header-menu',
                        'theme_location'    => 'header-menu',
                        'depth'             => 2,
                        'container'         => 'div',
                        'container_id'      => 'head-menu',
                        //'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                        //'walker'            => new wp_bootstrap_navwalker()
                    )
                );
                ?>
            </div>
        </div>
    </div>
</header>
