<form class="search_form" method="get" action="<?php echo home_url(); ?>" role="search">
	<input class="search_input" name="s" type="search" style="font-family:'Glyphicons Halflings'; word-spacing:-8px;" placeholder="&#xe003;">
	<button class="search_button" type="submit" role="button"><?php _e( 'Search' , 'epic_translate' ); ?></button>
</form>