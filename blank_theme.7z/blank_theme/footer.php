			<!-- footer -->
			<footer class="footer">
				<div class="container">
					<div class="foot_copyright">
						<div class="footc_item item1">
							NAZWA STRONY wszelkie prawa zastrzeżone 2017. Użyte w projekcie ikony pochodzą z flaticon.com
						</div>
						<div class="footc_item item2">
							POMYSŁ I REALIZACJA <a href="http://epicup.pl/" target="_blank">epicup.pl</a>
						</div>
						<div class="footc_item item3">
							<a href="http://epicup.pl/" target="_blank"><img class="svg_inject epicup_logo" src="<?php echo get_template_directory_uri() . '/img/epicup.svg'; ?>"></a>
						</div>
					</div>
				</div>
			</footer>
			<!-- /footer -->
		</div>
		<!-- /wrapper -->

		<?php wp_footer(); ?>

	</body>
	</html>
