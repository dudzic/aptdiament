<?php
function ajax_login_init()
{

    wp_register_script('login_ajax', get_template_directory_uri() . '/js/user_functions.min.js', array('jquery'));
    wp_enqueue_script('login_ajax');

    wp_localize_script('login_ajax', 'ajax_login_object', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'redirecturl' => home_url(),
        'loadingmessage' => __('Sending user info, please wait...')
    ));

    // Enable the user with no privileges to run ajax_login() in AJAX
    add_action('wp_ajax_nopriv_ajaxlogin', 'ajax_login');
}

// Execute the action only if the user isn't logged in
if (!is_user_logged_in()) {
    add_action('init', 'ajax_login_init');
}


function ajax_login()
{

    // First check the nonce, if it fails the function will break
    check_ajax_referer('ajax-login-nonce', 'security');

    // Nonce is checked, get the POST data and sign user on
    $info = array();
    $info['user_login'] = $_POST['username'];
    $info['user_password'] = $_POST['password'];
    $info['remember'] = true;

    $user_signon = wp_signon($info, false);
    if (is_wp_error($user_signon)) {
        echo json_encode(array('loggedin' => false, 'message' => __('Wrong username or password.')));
    } else {
        echo json_encode(array('loggedin' => true, 'message' => __('Login successful, redirecting...'), 'redirect'=> get_permalink( wc_get_page_id( 'checkout' ) )));
    }

    die();
}

add_action('wp_ajax_register_user_front_end', 'register_user_front_end', 0);
add_action('wp_ajax_nopriv_register_user_front_end', 'register_user_front_end');

function register_user_front_end()
{

    $new_user_firstname = stripcslashes($_POST['firstname']);
    $new_user_lastname = stripcslashes($_POST['lastname']);
    $new_user_email = stripcslashes($_POST['new_user_email']);
    $new_user_password = $_POST['new_user_password'];
    $user_nice_name = strtolower($_POST['new_user_email']);
    $user_data = array(
        'user_login'      => $new_user_email,
        'user_email'      => $new_user_email,
        'first_name'      => $new_user_firstname,
        'last_name'       => $new_user_lastname,
        'user_pass'       => $new_user_password,
        'user_nicename'   => $user_nice_name,
        'display_name'    => $new_user_first_name,
        'role'            => 'subscriber'
    );
    $user_id = wp_insert_user($user_data);
    // $user_id = wc_create_new_customer( $new_user_email, $user_nice_name, $new_user_password,$user_data ); //WC function

    if (!is_wp_error($user_id)) {
        //echo __('we have Created an account for you.');
        // update_user_meta($user_id, 'billing_first_name', $new_user_firstname); // WC part
        // update_user_meta($user_id, 'billing_last_name', $new_user_lastname); // WC part
        // $new_user_mail = new WC_Email_Customer_New_Account(); //WC function send email
        // $new_user_mail->trigger($user_id,$new_user_email);  //WC function  send email
        echo 'succes';
        autoLoginUser($new_user_email);
    } else {
        if (isset($user_id->errors['empty_user_login'])) {
            $notice_key = __('User Name and Email are mandatory');
            echo $notice_key;
        } elseif (isset($user_id->errors['existing_user_login'])) {
            echo __('User name already exist.');
        } elseif (isset($user_id->errors['existing_user_email']) || isset($user_id->errors['existing_user_login'])) {   
            echo __('There is already an account for this email address. Please log in or reset your password.');
        } elseif (isset($user_id->errors['registration-error-email-exists'])) {   
            echo __('There is already an account for this email address. Please log in or reset your password.');
        } else {
            echo __('Error Occured please fill up the sign up form carefully.');
        }
    }
    die;
}
function autoLoginUser($user_email)
{
    $user = get_user_by('email', $user_email);
    if ($user) {
        $user_id = $user->ID;
        wp_set_current_user($user_id, $user->user_login);
        wp_set_auth_cookie($user_id);
        do_action('wp_login', $user->user_login, $user);
    }
}

/*===================================
=            forgot pass            =
===================================*/

add_action('init', function () {
    add_action("wp_ajax_nopriv_lost_pass", "lost_pass");
    add_action("wp_ajax_lost_pass", "lost_pass");
});

function lost_pass()
{

    header('Content-Type: application/json');

    http_response_code(200);

    if (isset($_POST['user_login'])) {

        $email = $_POST['user_login'];

        if (empty($email)) {
            //http_response_code(400);
            $resp = array(
                'status' => 'error',
                'value' => __('Enter a username or e-mail address..')
            );
        } else if (!is_email($email)) {
            //http_response_code(401);
            $resp = array(
                'status' => 'error',
                'value' => __('Invalid username or e-mail address.')
            );
        } else if (!email_exists($email)) {
            //http_response_code(406);
            $resp = array(
                'status' => 'error',
                'value' => __('There is no user registered with that email address.')
            );
        } else {

            $retrieve_password = retrieve_password_by_mail($email);

            if ($retrieve_password) {
                //http_response_code(200);
                $resp = array(
                    'status' => 'success',
                    'value' => __('Check your email for the confirmation link.')
                );
            } else {
                //http_response_code(409);
                $resp = array(
                    'status' => 'error',
                    'value' => __('Something went wrong. Please try again later.')
                );
            }
        }
        echo json_encode($resp);
    }
    exit();
}


function retrieve_password_by_mail($user_login)
{
    global $wpdb;

    if (empty($user_login)) {
        return false;
    } elseif (strpos($user_login, '@')) {
        $user_data = get_user_by('email', trim(wp_unslash($user_login)));
        if (empty($user_data)) {
            return false;
        }
    } else {
        $login = trim($user_login);
        $user_data = get_user_by('login', $login);
    }

    do_action('lostpassword_post');

    if (!$user_data) {
        return false;
    }

    $user_login = $user_data->user_login;
    $user_email = $user_data->user_email;
    $key = get_password_reset_key($user_data);

    if (empty($key)) {
        // Generate something random for a key...
        $key = wp_generate_password(20, false);
        do_action('retrieve_password_key', $user_login, $key);
        // Now insert the new md5 key into the db
        $wpdb->update($wpdb->users, array('user_activation_key' => $key), array('user_login' => $user_login));
    }

    $message = __('Someone has requested a password reset for the following account:') . "\r\n\r\n";
    $message .= network_home_url('/') . "\r\n\r\n";
    $message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
    $message .= __('If this was a mistake, just ignore this email and nothing will happen.') . "\r\n\r\n";
    $message .= __('To reset your password, visit the following address:') . "\r\n\r\n";
    $message .= esc_url(home_url() . "/?action=rp&key=$key&login=" . rawurlencode($user_login)) . "\r\n";;

    if (is_multisite()) {
        $blogname = get_network()->site_name;
    } else {
        $blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
    }

    $title = sprintf(__('[%s] Password Reset'), $blogname);

    $title = apply_filters('retrieve_password_title', $title, $user_login, $user_data);

    $message = apply_filters('retrieve_password_message', $message, $key, $user_login, $user_data);

    if ($message && !wp_mail($user_email, wp_specialchars_decode($title), $message, array('Content-Type: text/html; charset=UTF-8'))) {
        return false;
    }

    return true;
}

/*=====  End of forgot pass  ======*/

add_action('wp_ajax_nopriv_reset_pass', 'reset_pass_callback');
add_action('wp_ajax_reset_pass', 'reset_pass_callback');
/*
 *  @desc   Process reset password
 */
function reset_pass_callback()
{
    header('Content-Type: application/json');

    http_response_code(200);

    $errors = new WP_Error();
    $nonce = $_POST['rs_user_reset_password_nonce'];

    if (!wp_verify_nonce($nonce, 'rs_user_reset_password_action')) {
        die('Security checked!');
    }

    $pass1  = $_POST['pass1'];
    $pass2  = $_POST['pass2'];
    $key    = $_POST['user_key'];
    $login  = $_POST['user_login'];

    $user = check_password_reset_key($key, $login);
    // check to see if user added some string


    if (is_wp_error($user)) {
        //$errors->add( 'password_required', __( 'Password is required field' ) );
        $resp = array(
            'status' => 'error',
            'value' => __('The key is invalid or has expired')
        );
        echo json_encode($resp);
        // return proper result
        die();
    }



    if (empty($pass1) || empty($pass2)) {
        //$errors->add( 'password_required', __( 'Password is required field' ) );
        $resp = array(
            'status' => 'error',
            'value' => __('Password is required field')
        );
        echo json_encode($resp);
        // return proper result
        die();
    }


    // is pass1 and pass2 match?
    if (isset($pass1) && $pass1 != $pass2) {
        //$errors->add( 'password_reset_mismatch', __( 'The passwords do not match.' ) );
        $resp = array(
            'status' => 'error',
            'value' => __('The passwords do not match.')
        );
        echo json_encode($resp);
        // return proper result
        die();
    }

    /**
     * Fires before the password reset procedure is validated.
     *
     * @since 3.5.0
     *
     * @param object           $errors WP Error object.
     * @param WP_User|WP_Error $user   WP_User object if the login and reset key match. WP_Error object otherwise.
     */
    do_action('validate_password_reset', $errors, $user);

    if ((!$errors->get_error_code()) && isset($pass1) && !empty($pass1)) {
        reset_password($user, $pass1);

        //$errors->add( 'password_reset', __( 'Your password has been reset.' ) );
        $resp = array(
            'status' => 'success',
            'value' => __('Your password has been reset.')
        );
    }

    // display error message
    // if ( $errors->get_error_code() ){
    //     echo '<p class="error">'. $errors->get_error_message( $errors->get_error_code() ) .'</p>';
    // }
    echo json_encode($resp);
    // return proper result
    die();
}