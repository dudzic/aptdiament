<?php

function general_scripts()
{
    if ($GLOBALS['pagenow'] != 'wp-login.php' && !is_admin()) {

        wp_register_script('no_conflict', get_template_directory_uri() . '/js/no_conflict.js', array('jquery'), '1.0.0');
        wp_enqueue_script('no_conflict');

        wp_register_script('buggyfill', get_template_directory_uri() . '/js/viewport-units-buggyfill.js', array(), '1.6.0', true);
        wp_enqueue_script('buggyfill');

        wp_register_script('bootstrap', get_template_directory_uri() . '/bootstrap/js/bootstrap.min.js', array(), '3.3.4', true);
        wp_enqueue_script('bootstrap');

        wp_register_script('slick', get_template_directory_uri() . '/js/slick.min.js', array(), '1.6.0', true);
        wp_enqueue_script('slick');

        wp_register_script('svg-injector', get_template_directory_uri() . '/js/svg-injector.min.js', array(), '1.0.0', true);
        wp_enqueue_script('svg-injector');

        wp_register_script('jquery-cookie', get_template_directory_uri() . '/js/jquery-cookie.min.js', array(), '1.0.0');
        wp_enqueue_script('jquery-cookie');

        wp_register_script('epicup-library', get_template_directory_uri() . '/js/epicup-library.min.js', array(), '1.0.0');
        wp_enqueue_script('epicup-library');

        // wp_register_script('simple-lightbox', get_template_directory_uri() . '/js/simple-lightbox.min.js', array(), '1.0.0', true);
        // wp_enqueue_script('simple-lightbox');

        // wp_register_script('parsley', get_template_directory_uri() . '/js/parsley.min.js', array(), '1.0.0', true);
        // wp_enqueue_script('parsley');

        wp_register_script('scripts', get_template_directory_uri() . '/js/scripts.min.js', array(), '1.0.0', true);
        wp_enqueue_script('scripts');

        /*===================================
        =            video embed            =
        ===================================*/
        
        wp_register_script('vimeo', get_template_directory_uri() . '/js/player.min.js', array(), '1.0.0', true);
        wp_enqueue_script('vimeo');

        wp_register_script('video', get_template_directory_uri() . '/js/video.min.js', array(), '1.0.0', true);
        wp_enqueue_script('video');
        
        /*=====  End of video embed  ======*/
        

        /*============================
        =            ajax            =
        ============================*/
        
        // wp_register_script('newsletter', get_template_directory_uri() . '/js/newsletter.min.js', array(), '1.0.0', true);
        // wp_enqueue_script('newsletter');
        // $url = add_query_arg("action", 'epic_newsletter', admin_url("admin-ajax.php"));
        // wp_localize_script('newsletter', 'newsletter' . "Handle", array("url" => $url));
        
        /*=====  End of ajax  ======*/
        
    }

    // if (is_page_template('page-temp/home.php')) {

    //     wp_register_script('home', get_template_directory_uri() . '/js/home.min.js', array(), '1.0.0', true);
    //     wp_enqueue_script('home');

    // }
    // 
    // if ( get_post_type() == "post_type" && is_single() ){
    // 
    // 
    // }
}

add_action( 'wp_enqueue_scripts', 'general_scripts' );
