<?php 

add_action('init', function(){
    add_action("wp_ajax_nopriv_epic_newsletter","epic_newsletter_new");
    add_action("wp_ajax_epic_newsletter","epic_newsletter_new");
});

function epic_newsletter_new(){

	header('Content-Type: application/json');

	http_response_code(200);

	if( isset( $_POST['email'] ) ){
		$api_key = get_field('newsl_api_key','option');
		$list_id = $_POST["list_id"];


		$MailChimp = new \DrewM\MailChimp\MailChimp($api_key);
		$MailChimp->verify_ssl = false;

		$email = $_POST["email"];
		$name = isset($_POST["name"]) ? $_POST["name"] : $email;

		$hash = $MailChimp->subscriberHash($email);

		$result = $MailChimp->put("lists/$list_id/members/$hash", array(
            'email_address' => $email,
            'merge_fields'  => array('FNAME'=>$name),
            'status'        => 'subscribed',
        ));

		if ($MailChimp->success()) {

			http_response_code(200);
			$resp = array(
				'status'	=> 200,
				'mailchip' 	=> $result
			);
		    echo json_encode($resp);   

		} else {

			http_response_code(400);
			$resp = array(
				'status'	=> 400,
				'mailchip' 	=> $MailChimp->getLastError()
			);

		    echo json_encode( $resp );

		}
	} else {

		http_response_code(401);
		$resp = array(
			'status'	=> 401,
			'mailchip' 	=> 'Email address is require'
		);
		echo json_encode( $resp );

	}
	exit();
}