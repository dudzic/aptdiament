<?php
function people() {

    $labels = array(
        'name'                => _x( 'People', 'Post Type General Name', 'text_domain' ),
        'singular_name'       => _x( 'People', 'Post Type Singular Name', 'text_domain' ),
        'menu_name'           => __( 'People', 'text_domain' ),
        'name_admin_bar'      => __( 'People', 'text_domain' ),
        'parent_item_colon'   => __( 'People:', 'text_domain' ),
        'all_items'           => __( 'All', 'text_domain' ),
        'add_new_item'        => __( 'New', 'text_domain' ),
        'add_new'             => __( 'New', 'text_domain' ),
        'new_item'            => __( 'New', 'text_domain' ),
        'edit_item'           => __( 'Edit', 'text_domain' ),
        'update_item'         => __( 'Update', 'text_domain' ),
        'view_item'           => __( 'View', 'text_domain' ),
        'search_items'        => __( 'Search', 'text_domain' ),
        'not_found'           => __( 'Not found', 'text_domain' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'text_domain' ),
    );
    $args = array(
        'label'               => __( 'People', 'text_domain' ),
        'description'         => __( 'People ', 'text_domain' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'editor','revisions'),
        'taxonomies'          => array( '' ),
        'hierarchical'        => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'menu_position'       => 5,
        'show_in_admin_bar'   => true,
        'show_in_nav_menus'   => true,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
        'menu_icon'           => 'dashicons-businessman',
        // 'rewrite' => array(
        //     'slug' => 'banking'
        // )
    );

    register_post_type( 'people', $args );

}

// Hook into the 'init' action
add_action( 'init', 'people', 0 );

add_action( 'init', 'build_taxonomie1', 0 );

function build_taxonomie1() {
    register_taxonomy( 'review', 'people', array(
        'hierarchical'                  => true,
        'label'                         => 'First',
        'query_var'                     => true,
        'rewrite'                       => true,
        'public'                        => true,
        'show_ui'                       => true,
        'show_in_menu'                  => true,
        'show_admin_column'             => true,
        'show_in_nav_menus'             => true,
        'show_tagcloud'                 => true
        )
    );
}


/* To make change in default post type */

// function revcon_change_post_label() {
//     global $menu;
//     global $submenu;
//     $menu[5][0] = 'News';
//     $submenu['edit.php'][5][0] = 'News';
//     $submenu['edit.php'][10][0] = 'Add News';
//     $submenu['edit.php'][16][0] = 'News Tags';
//     echo '';
// }
// function revcon_change_post_object() {
//     global $wp_post_types;
//     $labels = &$wp_post_types['post']->labels;
//     $labels->name = 'News';
//     $labels->singular_name = 'News';
//     $labels->add_new = 'Add News';
//     $labels->add_new_item = 'Add News';
//     $labels->edit_item = 'Edit News';
//     $labels->new_item = 'News';
//     $labels->view_item = 'View News';
//     $labels->search_items = 'Search News';
//     $labels->not_found = 'No News found';
//     $labels->not_found_in_trash = 'No News found in Trash';
//     $labels->all_items = 'All News';
//     $labels->menu_name = 'News';
//     $labels->name_admin_bar = 'News';
// }

// add_action( 'admin_menu', 'revcon_change_post_label' );
// add_action( 'init', 'revcon_change_post_object' );
// 
// Remove new post editor for post type post
// add_filter('use_block_editor_for_post', '__return_false', 10);