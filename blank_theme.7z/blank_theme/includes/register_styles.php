<?php

function styles()
{
	// wp_register_style('bootstrap', get_template_directory_uri() . '/bootstrap/css/bootstrap.min.css', array(), '3.3.4', 'all');
 //    wp_enqueue_style('bootstrap');

    wp_register_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '1.6.0', 'all');
    wp_enqueue_style('font-awesome');

    wp_register_style('slick', get_template_directory_uri() . '/css/slick.css', array(), '1.6.0', 'all');
    wp_enqueue_style('slick');

    // wp_register_style('simplelightbox', get_template_directory_uri() . '/css/simplelightbox.css', array(), '1.0', 'all');
    // wp_enqueue_style('simplelightbox');

    wp_register_style('style', get_template_directory_uri() . '/style.css', array(), '1.0', 'all');
    wp_enqueue_style('style');

    wp_register_style('styles', get_template_directory_uri() . '/css/styles.css', array(), '1.0', 'all');
    wp_enqueue_style('styles');

    wp_register_style('page', get_template_directory_uri() . '/css/page.css', array(), '1.0', 'all');
    wp_enqueue_style('page');
}

add_action( 'wp_enqueue_scripts', 'styles' );