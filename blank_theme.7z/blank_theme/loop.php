<?php
 ?>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<h1><?php the_title(); ?></h1>
	<h4>Posted on <?php the_time('F jS, Y') ?></h4>
	<p><?php the_content(); ?></p>
	<div class="read_more"><a href="<?php the_permalink(); ?>"><?php _e( 'Read more' , 'epic_translate' ); ?></a></div>
<?php endwhile; else: ?>
	<p><?php _e('Sorry, no posts matched your criteria.' , 'epic_translate' ); ?></p><?php endif; ?>
	<div class="pagination"><?php echo pagination(); ?></div>