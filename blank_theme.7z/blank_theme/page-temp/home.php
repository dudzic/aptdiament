<?php
/*
Template Name: Home
*/
?>

<?php
get_header();
epic_get_template('header-true.php');
?>

<main role="main">
	<div class="home_page">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="page_<?php the_ID(); ?>">
						<h1><?php the_title(); ?></h1>
						<?php if (have_posts()): while (have_posts()) : the_post(); ?>
							<div class="page_content">
								<?php the_content(); ?>
							</div>
						<?php endwhile; ?>
						<?php else: ?>
							<div class="nothing_d">
								<h2><?php _e( 'Nothing to display.' , 'epic_translate' ); ?></h2>
							</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</main>

<?php get_footer(); ?>