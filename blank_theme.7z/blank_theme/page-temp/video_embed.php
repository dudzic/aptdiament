<?php
/*
Template Name: Video embed
*/
?>

<?php
get_header();
epic_get_template('header-true.php');
?>

<main role="main">
	<div class="video_page">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="page_<?php the_ID(); ?>">
						<h1><?php the_title(); ?></h1>

						<?php 
						$video['url'] = '<iframe width="560" height="315" src="https://www.youtube.com/embed/CUNq2_VjRn4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'; 
						$video['url'] = '<iframe src="https://player.vimeo.com/video/241627658" width="640" height="360" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>';
						?>
						<?php if ( $video['url'] ): ?>
							<div class="video_wrap">
								<?php 
								$iframe = $video['url'];
								preg_match('/src="(.+?)"/', $iframe, $matches);
								$src = $matches[1];
								$src_array = parse_url($src);
								if ($src_array['host'] == 'www.youtube.com') {
									$params = array(
										'controls'		=> 0,
										'hd'			=> 1,
										'autohide'		=> 1,
										'autoplay'		=> 1
									);
									$new_src = add_query_arg($params, $src);
									$youtube_key = substr($src_array["path"],7);
									echo "<div id='ytplayer_".rand(0, 1000)."' class='ytplayer' data-key='".$youtube_key."'></div>";
								} elseif ( $src_array['host'] == 'player.vimeo.com' ) {
									$params = array(
										'autoplay'      => 0,
										'loop'          => 0,
										'portrait'      => 0,
										'badge'         => 0,
										'byline'        => 0,
										'player_id'     => 'vimeo_video_single'
									);
									$new_src = add_query_arg($params, $src);
									echo "<iframe class='vimeo_video' id='vimeo_video_single_".rand(0, 1000)."' frameborder='0' src='" . $new_src . "'></iframe>";
								}
								?>
								<div class="video_play">
									<img src="<?php echo get_template_directory_uri() . '/img/play.svg'; ?>" class="svg_inject">
								</div>
								<?php $img = get_template_directory_uri() . '/img/video_thumb.jpg'; ?>
								<div class="video_img lazyBg" data-src="<?php echo $img ?>"></div>
								<div class="video_desc"><?php echo $video['desc'] ?></div>
							</div>
						<?php endif ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</main>

<?php get_footer(); ?>