<?php
get_header();
epic_get_template('header-true.php');
?>

<main role="main">
	<div class="p404">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h2>404</h2>
					<h3><?php _e( 'Nothing to do here...' , 'epic_translate' ); ?></h3>
				</div>
			</div>
		</div>
	</div>
</main>

<?php get_footer(); ?>