(function ($, root, undefined) {	
	$(function () {
		$=jQuery.noConflict();
	});	
})(jQuery, this);