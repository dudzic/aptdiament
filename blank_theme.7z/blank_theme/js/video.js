(function ($, root, undefined) {
	$(function () {

		/*=============================
		=            Vimeo            =
		=============================*/
		if ( jQuery('.vimeo_video').length ) {
			jQuery('.vimeo_video').each(function () {
				var iframe = $(this)[0];
				var player = new Vimeo.Player(iframe),
				$self = $(this);

				// player.setVolume(0);
				// player.play();

				player.on('play', function() {
					$self.closest('.video_wrap').addClass('video_active');
				});
			
			})
		}

		/*=====  End of Vimeo  ======*/
		
	});
})(jQuery, this);




/*===============================
=            Youtube            =
===============================*/
if ( jQuery('.ytplayer').length ) {
	var tag = document.createElement('script');
	tag.src = "https://www.youtube.com/player_api";
	var firstScriptTag = document.getElementsByTagName('script')[0];
	firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

	var playersY = {};
	setTimeout(function () {
		jQuery('.ytplayer').each(function () {
			var element = jQuery(this),
			wrap = element.closest('.video_wrap');

			var key = element.data('key');
			var id = element.attr('id');
			playersY[id] = new YT.Player(id, {
				height: '390',
				width: '640',
				videoId: key,
				playerVars: {
					'controls': 1,
				    'loop': 1,
				    'playlist':key,
				    'autohide': 1,
				    'autoplay': 0,
				    'iv_load_policy': 3,
					'rel': 0,
					'showinfo': 0,

				},
				events: {
					onStateChange: function (event) {
						if (event.data==1) {
							wrap.addClass('video_active');
						}
					}
				}
			});

		})
	},2000)
}

/*=====  End of Youtube  ======*/