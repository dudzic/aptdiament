(function ($, root, undefined) {

	var form = $('.newsletter_form');


		form.parsley();

		form.on('submit', function(e) {
			jQuery.ajax({
				url: mailchimp_newHandle.url,
				type: "POST",
				data: form.serialize()+'&action=epic_newsletter',
				success: function(response) {
					if (response.status == 200) {
						form.addClass('succes');
						form.find('input').val('');
						form.removeClass('error_exist');
					}
					
				},
				error: function (response) {
					if (response.status == 400) {
						form.addClass('error_exist');
						form.removeClass('succes');
						form.find('input[name="email"]').addClass('parsley-error');
					}
				} 
			});
			return false;
			e.preventDefault();
		});

})(jQuery, this);