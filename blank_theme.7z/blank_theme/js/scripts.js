(function ($, root, undefined) {
	
	$(function () {
		/*=================================
		=            Animation            =
		=================================*/
		
		$('.element_anim,.element_anim_1,.element_anim_2,.element_anim_3,.element_anim_4,.element_anim_5,.fade_anim_1,.fade_anim_2,.fade_anim_3').scroll_anim(0,0);
		
		/*=====  End of Animation  ======*/
	});
	
})(jQuery, this);