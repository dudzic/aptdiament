(function ($, root, undefined) {

    $(function () {
        $(document).ready(function () {
            

            $('form.login_form, form.register, form#lostPasswordForm, form#resetPasswordForm').parsley();

            $('form.login_form').on('submit', function (e) {
                var self = $(this);
                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    url: ajax_login_object.ajaxurl,
                    data: {
                        'action': 'ajaxlogin', //calls wp_ajax_nopriv_ajaxlogin
                        'username': self.find('#login_email').val(),
                        'password': self.find('#login_passwd').val(),
                        'security': self.find('#security').val()
                    },
                    success: function (data) {
                        self.find('p.status').text(data.message);
                        if (data.loggedin) {
                            document.location.href = document.location.href;
                        }

                    }
                });
                e.preventDefault();
                return false;
            });

            $('form.register').on('submit', function (e) {
                var self = $(this);
                $.ajax({
                    type: "POST",
                    url: ajax_login_object.ajaxurl,
                    data: {
                        action: "register_user_front_end",
                        new_user_name: self.find('#email_registration').val(),
                        firstname: self.find('#first_name_registration').val(),
                        lastname: self.find('#last_name_registration').val(),
                        new_user_email: self.find('#email_registration').val(),
                        new_user_password: self.find('#passwd_registration').val()
                    },
                    success: function (results) {
                        if (results == 'succes') {
                            self.find('input:not([type="submit"])').val('');
                            window.location.reload(true);
                        } else {
                            self.find('.status').show().text(results);
                        }
                    },
                    error: function (results) {}
                });
                e.preventDefault();
                return false;
            });

            $("form#lostPasswordForm").submit(function (e) {
                $.ajax({
                    type: "POST",
                    url: ajax_login_object.ajaxurl,
                    data: $("form#lostPasswordForm").serialize() + '&action=lost_pass',
                    success: function (results) {
                        if (results.status == 'error') {
                            $('form#lostPasswordForm .status').html(results.value);
                        }
                        if (results.status == 'success') {
                        }
                    },
                    error: function (results) {
                    }
                });
                e.preventDefault();
                return false;
            });

            $("form#resetPasswordForm").submit(function (e) {
                $.ajax({
                    type: "POST",
                    url: ajax_login_object.ajaxurl,
                    data: $("form#resetPasswordForm").serialize() + '&action=reset_pass',
                    success: function (results) {
                        if (results.status == 'error') {
                            $('form#resetPasswordForm .status').html(results.value);
                        }
                        if (results.status == 'success') {
                            
                        }
                    },
                    error: function (results) {
                    }
                });
                e.preventDefault();
            });

        });
    });

})(jQuery, this);