<?php
get_header();
epic_get_template('header-true.php');
?>

<main role="main">
	<div class="index">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<?php get_template_part('searchform'); ?>
					<?php get_template_part('loop'); ?>
				</div>
			</div>
		</div>
	</div>
</main>

<?php get_footer(); ?>