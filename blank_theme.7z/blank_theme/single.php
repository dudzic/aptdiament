<?php
get_header();
epic_get_template('header-true.php');
?>

<main role="main">
	<div class="single_post">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<?php if (have_posts()): while (have_posts()) : the_post(); ?>
						<div id="post_<?php the_ID(); ?>" <?php post_class(); ?>>
							<h1>
								<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
							</h1>
							<?php the_content();?>
						</div>
					<?php endwhile; ?>
					<?php else: ?>
						<div class="nothing_d">
							<h1><?php _e( 'Nothing to display.' , 'epic_translate' ); ?></h1>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</main>

<?php get_footer(); ?>
